(() => {
var exports = {};
exports.id = 881;
exports.ids = [881];
exports.modules = {

/***/ 3236:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3236));
module.exports = __webpack_exports__;

})();